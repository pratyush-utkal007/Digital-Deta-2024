function Body() {
  return (
    <div className="w-full h-screen bg-[url('../Image/bg.jpg')]">
    </div>
  );
}

export default Body;
