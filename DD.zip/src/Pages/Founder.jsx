function Founder() {
  return (
    <>
      <div>
        <div className="bg-[url('./Image/pattern-sample.jpg')] h-screen"></div>
      </div>
    </>
  );
}

export default Founder;
